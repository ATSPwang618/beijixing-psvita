Borealis Demo - Windows版本

运行方法:
1. 双击 start.bat 启动应用程序
2. 或者直接运行 borealis_demo.exe

系统要求:
- Windows 7 或更高版本 (64位)
- 无需安装额外的运行时库

文件说明:
- borealis_demo.exe: 主程序
- start.bat: 启动脚本
- resources/: 资源文件目录

项目主页: https://github.com/ATSPwang618/music-player-test

